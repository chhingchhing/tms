<!-- Modal -->
<div class="modal fade" id="suppliers" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <?php $this->load->view("suppliers/_form"); ?>
</div><!-- /.modal
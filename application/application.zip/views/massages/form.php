<!-- Modal -->
<div class="modal fade" id="massages" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <?php $this->load->view("massages/_form"); ?>
</div><!-- /.modal -->


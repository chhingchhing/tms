<!-- Modal -->
<div class="modal fade" id="guides" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <?php $this->load->view("guides/_form"); ?>
</div><!-- /.modal -->


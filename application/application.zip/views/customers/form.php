<!-- Modal -->
<div class="modal fade" id="customers" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <?php $this->load->view("customers/_form"); ?>
</div><!-- /.modal -->
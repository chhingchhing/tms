<!-- Modal -->
<div class="modal fade" id="bikes" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <?php $this->load->view('bikes/_form'); ?>
</div><!-- /.modal -->
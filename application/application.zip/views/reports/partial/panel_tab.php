<div class="row" id="title_bar">
    <div id="page_title" class="col-10 col-sm-10 col-lg-10" style="margin-bottom:8px;">
    	<table id="title_bar">
			<tr>
				<td id="title_icon">
					<img src='<?php echo base_url()?>images/menubar/reports.png' alt='<?php echo lang('reports_reports'); ?> - <?php echo lang('reports_welcome_message'); ?>' />
				</td>
				<td id="title"><?php echo lang('reports_reports'); ?> - <?php echo $title ?></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td><small><?php echo $subtitle ?></small></td>
			</tr>
		</table>
    </div>
</div>
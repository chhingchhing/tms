<?php $this->load->view("partial/header"); ?>
<div id="register_container" class="receiving">
	<?php $this->load->view("receivings/receiving"); ?>
</div>
<?php $this->load->view("partial/footer"); ?>
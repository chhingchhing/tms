<!-- Modal -->
<div class="modal fade" id="tours_package" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <?php $this->load->view("tours/_form_package"); ?>
</div><!-- /.modal -->
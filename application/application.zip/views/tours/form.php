<!-- Modal -->
<div class="modal fade" id="tours" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <?php $this->load->view("tours/_form"); ?>
</div><!-- /.modal -->


<!--input employee form-->
<div class="modal fade" id="employees" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <?php $this->load->view("employees/_form"); ?>
</div><!-- /.modal -->

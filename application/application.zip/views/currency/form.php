<!-- Modal -->
<div class="modal fade" id="currency" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <?php $this->load->view("currency/_form"); ?>
</div><!-- /.modal -->
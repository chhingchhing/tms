<?php
$lang['bikes_basic_information']='Bike Information';
$lang['bikes_bike_code']='Bike code';
$lang['bikes_available']='Available';
$lang['bikes_unit_price']='Unit Price';
$lang['bikes_actual_price']='Actual Price';
$lang['bikes_bike_types']='Bike Type';
$lang['bikes_option_value']='please select one';


?>
<?php
//$lang['massages_new']='New Massage';
$lang['massages_time_in'] = 'Time In';
$lang['massages_add_time_in'] = 'Add Time In';
$lang['massages_add_time_out'] = 'Add Time Out';
$lang['massages_time_out'] = 'Time Out';
$lang['massages_clearnup_old_massage']='Cleanup old Massage';
$lang['massages_customer']='Massage';
$lang['massages_update']='Update Massage';
$lang['massages_mass_update']='massages Mass Update';
$lang['massages_confirm_delete']='Are you sure you want to delete the selected massages?';
$lang['massages_none_selected']='You have not selected any massages to delete';
$lang['massages_error_adding_updating'] = 'Error adding/updating customer';
$lang['massages_successful_adding']='You have successfully added customer';
$lang['massages_successful_updating']='You have successfully updated customer';
$lang['massages_successful_deleted']='You have successfully deleted';
$lang['massages_one_or_multiple']='customer(s)';
$lang['massages_cannot_be_deleted']='Could not deleted selected massages, one or more of the selected massages has sales.';
$lang['massages_basic_information']='Massages Information';
$lang['massages_account_number']='Account #';
$lang['massages_company_name']='Company Name';
$lang['massages_massage_id']='Massage Id';
$lang['massages_taxable']='Taxable';
$lang['massages_most_imported_some_failed'] = 'Most massages imported. But some were not, here is list of their CODE';
$lang['massages_import_successfull'] = 'Import massages successfull';
$lang['massages_mass_import_from_excel'] = 'Mass import data from excel sheet';
$lang['massages_download_excel_import_template'] = 'Download Import Excel Template (CSV)';
$lang['massages_download_excel_mass_update_template'] = 'Download Excel Mass Update Template (CSV)';
$lang['massages_import'] = 'Import';
$lang['massages_full_path_to_excel_required'] = 'Full path to excel file required';
$lang['massages_import_massages_from_excel'] = 'Import massages from Excel';
$lang['massages_duplicate_account_id'] = 'Your import has failed due to duplicate customer id or invalid data, please check your .csv file and try again';
$lang['massages_cleanup_old_massages'] = 'Cleanup old massages';
$lang['massages_cleanup_sucessful'] = 'massages cleaned successfuly';
$lang['massages_confirm_cleanup'] = 'Are you sure you want to clean ALL deleted massages? (This will remove account numbers from deleted massages so they can be reused)';
$lang['massages_duplicate_exists'] = 'A similar customer name already exists. Do you want to continue?';
$lang['massages_payamount_required']='The amount is a required field.';
$lang['massages_payamount_number']='Amount must be a number';
$lang['massages_due_amount'] = 'Balance to pay';
$lang['massages_amount_pay'] = 'Amount';
$lang['massages_delete_cc_info'] = 'Delete credit card Info';
$lang['massage_sale'] = '  Sale Massage';

$lang['common_massage_name']='Massages Name';
$lang['common_massage_desc']='Description';
$lang['common_price_one_haft']='Price one half';
$lang['common_supplier_id']='Supplier';
$lang['common_price_haft']='Price half';
$lang['common_price_one']='Sale Price($/h)';
$lang['common_actual_price']='Actual Price($/h)';
$lang['common_massage_typesID']='Massage Typed';
$lang['common_item_massage_id']='Item Massage';
$lang['common_deleted']=' Delete';
// New 04/08/2014​​​​​​ 
$lang['massages_commission_price_massager']=' Massager Commission($)';
$lang['massages_commission_price_receptionist']=' Receptionist Commission($)';

?>
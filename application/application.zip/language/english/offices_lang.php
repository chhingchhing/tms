<?php
$lang['office_world_1']='Office 1';
$lang['office_world_1_desc']='Office 1';
$lang['office_world_2']='Office 2';
$lang['office_world_2_desc']='Office 2';
$lang['office_world_3']='Office 3';
$lang['office_world_3_desc']='Office 3';
$lang['office_world_4']='Office 4';
$lang['office_world_4_desc']='Office 4';
$lang['office_world_5']='Office 5';
$lang['office_world_5_desc']='Office 5';
$lang['office_world_6']='Office 6';
$lang['office_world_6_desc']='Office 6';

$lang['offices_new']=' New Office';
$lang['offices_name']='Office Name';
$lang['offices_address']='Office Address';
$lang['offices_no_offices_display'] = 'No offices to display';
$lang['offices_successful_adding']='You have successfully added office';
$lang['offices_successful_updating']='You have successfully updated office';
$lang['offices_error_adding_updating'] = 'Error adding/updating office';
$lang['offices_successful_deleted']='You have successfully deleted';
$lang['offices_one_or_multiple']='office(s)';
$lang['offices_cannot_be_deleted']='Could not deleted selected office';
$lang['offices_list_view']=' List View';
$lang['offices_id']='Office ID';

?>
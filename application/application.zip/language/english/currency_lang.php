<?php
$lang['currency_currency']='Currency';
$lang['currency_new']=' New Currency';
$lang['currency_id']='Currency ID';
$lang['currency_no_currency_display'] = 'No currency to display';
$lang['currency_update']='Update Currency';
$lang['currency_currency_value']='Currency Value';
$lang['currency_type_name']='Currency Type';
$lang['currency_value']='Currency Rate';
$lang['currency_basic_information']='Currency Information';
$lang['currency_successful_adding']='You have successfully added currency';
$lang['currency_successful_updating']='You have successfully updated currency';
$lang['currency_error_adding_updating'] = 'Error adding/updating currency';
$lang['currency_successful_deleted']='You have successfully deleted';
$lang['currency_one_or_multiple']='currency(s)';
$lang['currency_cannot_be_deleted']='Could not deleted selected currency.';
$lang['currency_currency_symbol']='Currency Symbol';
?>
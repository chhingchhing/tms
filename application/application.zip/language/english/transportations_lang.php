<?php
$lang['transports_transport_id'] = 'No';
$lang['transports_company_name'] = 'Company Name';
$lang['transports_taxi_fname'] = 'First Name';
$lang['transports_taxi_lname'] = 'Last Name';
$lang['transports_phone'] = 'Tel';
$lang['transports_mark'] = 'Mark';
$lang['transports_action'] = 'Action';
$lang['transports_no_guide_display'] = 'No transportations to display';
$lang['transportations_new']=' New Transportations';
$lang['transport_infor']='Transportation Information';
$lang['transport_company_name']='Company Name';
$lang['transport_company_names']='Company Name';
$lang['transport_taxi_name']='Driver';
$lang['transport_phones']='Tel';
$lang['transport_marks']='Mark';
$lang['transport_phone']='Tel';
$lang['transport_mark']='Mark';
$lang['transports_vehicle']='Vehicle';

?>
<?php
$lang['guides_guide_id'] = 'Guide Id';
$lang['guides_guide_name'] = 'Guide Name';
$lang['guides_gender'] = 'Gender';
$lang['guides_tel'] = 'Tel';
$lang['guides_email'] = 'Email';
$lang['guides_guide_type'] = 'Guide type';
$lang['guides_guide_action'] = 'Action';
$lang['guides_no_guide_display'] = 'No Guide to display';
$lang['guides_new']=' New Guide';
$lang['guides_successful_deleted']='You have successfully deleted';
$lang['guides_cannot_be_deleted']='Could not deleted selected guide, one or more of the selected guide.';

?>
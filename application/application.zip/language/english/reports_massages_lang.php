<?php
$lang['reports_report_massages'] = 'Reports Massages';
$lang['reports_massages'] = 'Massages';
$lang['summary_reports_issue_date'] = 'Issue date';
$lang['summary_reports_kind_mas'] = 'Kind of massages';
$lang['summary_reports_price'] = 'Price';
$lang['summary_reports_time_out'] = 'Time out';
$lang['summary_reports_time_in'] = 'Time in';
$lang['summary_reports_total_time'] = 'Total time';
$lang['summary_reports_total'] = 'Total';
$lang['summary_reports_staff'] = 'Staff name';
$lang['summary_reports_massage_id'] = 'Massage ID';
$lang['summary_reports_massage_time_in'] = 'Time in';
$lang['summary_reports_massage_time_out'] = 'Time out';
$lang['summary_reports_massage_name'] = 'Massage Name';
$lang['summary_reports_massage_cost'] = 'Cost Price';
$lang['summary_reports_massage_sale_price'] = 'Sale Price';
$lang['summary_reports_massage_qty'] = 'Quantity (hours)';
$lang['summary_reports_massage_comment'] = 'Comment';
$lang['summary_reports_massage_disc'] = 'Discount ($)';
$lang['summary_reports_massage_commission_price'] = 'Commissioner Price';
$lang['summary_reports_massage_total_commissioner_price']= 'Total Commissioner Price';
$lang['reports_reports_massage_summary_report'] = 'Massages Summary Report';
$lang['summary_reports_massage_massager'] = 'Massager';
$lang['summary_reports_massage_office'] = 'Office';

?>
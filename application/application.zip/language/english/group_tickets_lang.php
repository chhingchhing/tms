<?php
// Start Chhingchhing
$lang['group_tickets_ticket_id'] = 'Ticket Id';
$lang['group_tickets_ticket_code'] = 'Ticket Code';
$lang['group_tickets_ticket_type_id'] = 'Ticket Type';
$lang['group_tickets_ticket_destination'] = 'Destination';
$lang['tickets_no_group_ticket_display'] = 'No group tickets data for display';


?>
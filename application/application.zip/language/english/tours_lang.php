<?php
$lang['tours_tour_name']=' Tour Name';
$lang['tour_tour_name'] = 'Tour Name';
$lang['tour_name']='Tour Name';
$lang['tours_basic_information']='Tour Information';
$lang['tour_tour_id']='No';
$lang['tour_deleted']=' Deleted';
$lang['tour_departure_date']='Departure Date';
$lang['tours_departure_date']='Departure date';
$lang['tours_departure_time']='Departure time';
$lang['tours_by']='By';
$lang['tours_price']='Price';
$lang['tours_destination_name']='Destination';
$lang['tours_supplier']='Supplier';
$lang['tours_desc']='Description';
$lang['tour_sale']=' Sale Tour';
$lang['tours_successful_deleted']='You have successfully deleted';
$lang['tours_cannot_be_deleted']='You have error with delete.';
$lang['summary_reports_tour_customer_name']='Customer Name';

$lang['tours_list_view_package']=' List Tour Package';
$lang['tours_list_view']=' List Tour';
$lang['tours_new_tour_package']=' New Package';
$lang['tours_package_excel_export']=' Excel Export Package';
?>
<?php
$lang['commissioners_id'] = 'No';
$lang['commissioners_first_name'] = 'First name';
$lang['commissioners_last_name'] = 'Last name';
$lang['commissioners_name'] = 'Name';
$lang['commissioners_tel'] = 'Tel';
$lang['commissioners_action'] = 'Action';
$lang['commis_no_guide_display'] = 'No transportations to display';
$lang['commissioners_new']=' New Commissioner';
$lang['transport_info']='Transportation Information';
$lang['transport_company_name']='Company Name';
$lang['transport_taxi_name']='Driver';
$lang['transport_phone']='Tel';
$lang['transport_mark']='Mark';
$lang['commissioners_successful_deleted']='You have successfully deleted';
$lang['commissioners_one_or_multiple']='comissioner(s)';
$lang['commissioners_cannot_be_deleted']='Could not deleted selected commissioners, one or more of the selected commissioners has sales.';

?>
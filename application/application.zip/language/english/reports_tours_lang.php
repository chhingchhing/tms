<?php
$lang['reports_reports_tours'] = 'Reports Tours';
$lang['reports_tours'] = 'Tours';
$lang['summary_reports_issue_date'] = 'Issue date';
$lang['summary_reports_departure'] = 'Departure';
$lang['summary_reports_transport_by'] = 'Transport';
$lang['summary_reports_destination'] = 'Destination';
$lang['summary_reports_time'] = 'Time';
$lang['reports_items_summary_report'] = 'Items Summary Report';
$lang['summary_reports_hotel_name'] = 'Hotel name';
$lang['reports_taxes_summary_report'] = 'Taxes Summary Report';
$lang['summary_reports_room'] = 'Room';
$lang['summary_reports_company'] = 'Company';
$lang['summary_reports_num_pass'] = 'Passenger number';
$lang['summary_reports_guide'] = 'Guide';
$lang['summary_reports_code_invoice'] = 'Code invoice';
$lang['summary_reports_pass_name'] = 'Passenger name';
$lang['summary_reports_actual_price'] = 'Actual price';
$lang['summary_reports_total'] = 'Total';
$lang['summary_reports_deposit'] = 'Deposit';
$lang['summary_reports_balance'] = 'Balance';
$lang['summary_reports_commissioner'] = 'Commissioner';
$lang['summary_reports_time_sale'] = 'Time sale';
$lang['summary_reports_seller'] = 'Seller';

?>
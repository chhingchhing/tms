<?php
$lang['transports_transport_id'] = 'ល.រ';
$lang['transports_company_name'] = 'ឈ្មោះក្រុមហ៊ុន';
$lang['transports_taxi_fname'] = 'នាម';
$lang['transports_taxi_lname'] = 'នាម​ត្រកូល';
$lang['transports_phone'] = 'លេខទូរសព្ទ';
$lang['transports_mark'] = 'ពិពណ៍នា';
$lang['transports_action'] = 'សកម្មភាព';
$lang['transports_no_guide_display'] = 'គ្មានទិន្នន័យសំរាប់បង្ហាញទេ!';
$lang['transportations_new']=' ការដឹកជញ្ជូនថ្មី';
$lang['transport_infor']='ពត៍មានអំពីការដឹកជញ្ជូន';
$lang['transport_company_name']='ឈ្មោះក្រុមហ៊ុន';
$lang['transport_company_names']='ឈ្មោះក្រុមហ៊ុន';
$lang['transport_taxi_name']='អ្នកបើកបរ';
$lang['transport_phones']='លេខទូរសព្ទ័';
$lang['transport_marks']='ការពិពណ៍នា';
$lang['transport_phone']='លេខទូរសព្ទ័';
$lang['transport_mark']='ការពិពណ៍នា';
$lang['transports_vehicle']='ប្រភេទរថយន្ត';

?>
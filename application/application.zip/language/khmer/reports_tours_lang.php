<?php
$lang['reports_reports_tours'] = 'របាយការណ៍​ ទេសចរណ៍';
$lang['reports_tours'] = 'ទេសចរណ៍';
$lang['summary_reports_issue_date'] = 'កាលបរិច្ឆេទ លក់';
$lang['summary_reports_departure'] = 'ការចេញដំណើរ';
$lang['summary_reports_transport_by'] = 'មធ្យោបាយ';
$lang['summary_reports_destination'] = 'ទិសដៅ';
$lang['summary_reports_time'] = 'ពេលវេលា';
$lang['reports_items_summary_report'] = 'Items Summary Report';
$lang['summary_reports_hotel_name'] = 'ឈ្មោះ សណ្ឋាគារ';
$lang['reports_taxes_summary_report'] = 'Taxes Summary Report';
$lang['summary_reports_room'] = 'បន្ទប់';
$lang['summary_reports_company'] = 'ក្រុមហ៊ុន';
$lang['summary_reports_num_pass'] = 'ចំនួនអ្នកដំណើរ';
$lang['summary_reports_guide'] = 'មគ្គុទេស';
$lang['summary_reports_code_invoice'] = 'លេខកូដវិកយ័បត្រ';
$lang['summary_reports_pass_name'] = 'ឈ្មោះអ្នកដំណើរ';
$lang['summary_reports_actual_price'] = 'តំលៃដើម';
$lang['summary_reports_total'] = 'សរុប';
$lang['summary_reports_deposit'] = 'លុយកក់';
$lang['summary_reports_balance'] = 'លុយអាប់';
$lang['summary_reports_commissioner'] = 'អ្នកនាំភ្ញៀវ';
$lang['summary_reports_time_sale'] = 'ម៉ោងលក់';
$lang['summary_reports_seller'] = 'អ្នកលក់';

?>
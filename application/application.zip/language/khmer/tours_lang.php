<?php
$lang['tours_tour_name']=' ឈ្មោះទេសចរណ៍';
$lang['tour_tour_name'] = 'ឈ្មោះទេសចរណ៍';
$lang['tour_name']=' ឈ្មោះទេសចរណ៍';
$lang['tours_basic_information']='ពត៍មានអំពីទេសចរណ៍';
$lang['tour_tour_id']='ល.រ';
$lang['tour_deleted']=' លុប';
$lang['tour_departure_date']='ថ្ងៃខែចេញដំណើរ';
$lang['tours_departure_date']='ថ្ងៃខែចេញដំណើរ';
$lang['tours_departure_time']='ម៉ោងចេញដំណើរ';
$lang['tours_by']='ដោយ';
$lang['tours_price']='តម្លៃ';
$lang['tours_destination_name']='ទិសដៅ';
$lang['tours_supplier']='អ្នកផ្គត់ផ្គង់';
$lang['tours_desc']='ការពិពណ៍នា';
$lang['tour_sale']=' សេវាកម្មទេសចរណ៍';
$lang['tours_successful_deleted']='ការលុបរបស់អក្នបានជោគជ័យ';
$lang['tours_cannot_be_deleted']='មានបញ្ហាក្នុងការលុបទេសចរណ៍';
$lang['summary_reports_tour_customer_name']='ឈ្មោះអតិថិជន';

$lang['tours_list_view_package']=' ប​ញ្ជីកញ្ចប់ដំណើរកំសាន្ដ';
$lang['tours_list_view']=' ប​ញ្ជីដំណើរកំសាន្ដ';
$lang['tours_new_tour_package']=' កញ្ចប់ដំណើរកំសាន្ដថ្មី';
$lang['tours_package_excel_export']=' Excel Export Package';
?>
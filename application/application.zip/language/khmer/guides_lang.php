<?php
$lang['guides_guide_id'] = 'មគ្គុទេស Id';
$lang['guides_guide_name'] = 'ឈ្មោះ មគ្គុលទេស';
$lang['guides_gender'] = 'ភេទ';
$lang['guides_tel'] = 'លេខទូរសព្ទ័';
$lang['guides_email'] = 'អ៊ី-ម៉ែល';
$lang['guides_guide_type'] = 'ប្រភេទ មគ្គុទេស';
$lang['guides_guide_action'] = 'សកម្មភាព';
$lang['guides_no_guide_display'] = 'ពុំមានមគ្គុទេស​​​ សំរាប់បង្ហាញទេ';
$lang['guides_new']=' មគ្គុទេស​ ថ្មី';
$lang['guides_successful_deleted']='ការ​លុប​របស់​អ្នក​បាន​ជោគជ័យ​';
$lang['guides_cannot_be_deleted']='មិនអាចលុបមគ្គុទេសនេះបានទេ ពីព្រោះ មានមគ្គុទេសខ្លះត្រូវបានគេជ្រើសរើសរួចហើយ។';

?>
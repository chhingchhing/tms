<?php
$lang['bikes_basic_information']='ពត៍មានអំពីកង់';
$lang['bikes_bike_code']='លេខសំគាល់កង់';
$lang['bikes_available']='ទំនេរ';
$lang['bikes_unit_price']='តម្លៃមួយៗ';
$lang['bikes_actual_price']='តម្លៃដើម';
$lang['bikes_bike_types']='ប្រភេទកង់';
$lang['bikes_option_value']='តម្លៃលក់មួយៗ';
$lang['bikes_new'] = '​ បន្ថែមកង់ថ្មី';

$lang['bikes_action']='សកម្មភាព';
$lang['bikes_sale']=' ជួរកង់';

// for rent bike
$lang['bike_code_exist'] = 'កូដកង់មួយនេះមាននៅក្នុងកន្ត្រក់រួចហើយ!';
$lang['date_out']='ម៉ោងចេញ';
$lang['date_in']='ម៉ោងចូល';
$lang['bikes_successful_deleted']='ការលុបរបស់អ្នកបានជោគជ័យ';
$lang['bikes_one_or_multiple']='កង់(s)';
$lang['bikes_cannot_be_deleted']='មិនអាចលុប កង់ នេះទេពីព្រោះ កង់ នេះត្រូវបានគេ ជួរ​ ​ហើយ។';
?>
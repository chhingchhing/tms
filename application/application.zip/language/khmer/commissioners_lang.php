<?php
$lang['commissioners_id'] = 'ល.រ';
$lang['commissioners_first_name'] = 'នាម';
$lang['commissioners_last_name'] = 'គោត្តនាម';
$lang['commissioners_name'] = 'ឈ្មោះ';
$lang['commissioners_tel'] = 'លេខទូរសព្ទ័';
$lang['commissioners_action'] = 'សកម្មភាព';
$lang['commis_no_guide_display'] = 'ពុំមានការអ្នកនាំភ្ញៀវណាមួយសំរាប់បង្ហាញទេ!';
$lang['commissioners_new']='​ អ្នកនាំភ្ញៀវថ្មី';
$lang['transport_info']='ពត៏មាន នៃ ការដឹកជញ្ជួន';
$lang['transport_company_name']='ឈ្មោះក្រុមហ៊ុន';
$lang['transport_taxi_name']='អ្នកបើកបរ';
$lang['transport_phone']='លេខទូរសព្ទ័';
$lang['transport_mark']='កំណត់ចំណាំ';
$lang['commissioners_successful_deleted']='ការលុបរបស់អក្នបានជោគជ័យ';
$lang['commissioners_one_or_multiple']='អ្នកនាំភ្ញៀវ(s)';
$lang['commissioners_cannot_be_deleted']='ការលុបមានបញ្ហា, អ្នកមិនអាចលុបអ្នកនាំភ្ញៀវបានទេ';

?>
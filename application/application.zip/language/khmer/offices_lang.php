<?php
$lang['office_world_1']='ការិយាល័យទី​ ១';
$lang['office_world_1_desc']='ការិយាល័យទី ១';
$lang['office_world_2']='ការិយាល័យទី ២';
$lang['office_world_2_desc']='ការិយាល័យទី ២';
$lang['office_world_3']='ការិយាល័យទី ៣';
$lang['office_world_3_desc']='ការិយាល័យទី ៣';
$lang['office_world_4']='ការិយាល័យទី ៤';
$lang['office_world_4_desc']='ការិយាល័យទី ៤';
$lang['office_world_5']='ការិយាល័យទី ៥';
$lang['office_world_5_desc']='ការិយាល័យទី ៥';
$lang['office_world_6']='ការិយាល័យទី ៦';
$lang['office_world_6_desc']='ការិយាល័យទី ៦';

$lang['offices_new']=' ការិយាលយ័ថ្មី';
$lang['offices_name']='ឈ្មោះការិយាលយ័';
$lang['offices_address']='អស័យដ្ថាន នៃ ការិយាលយ័';
$lang['offices_no_offices_display'] = 'គ្មានការិយាលយ័ណាមួយសម្រាប់បង្ហាញទេ';
$lang['offices_successful_adding']='អ្នកបន្ថែមការិយាលយ័ថ្មីបានជោគជយ័';
$lang['offices_successful_updating']='អ្នកកែប្រែការិយាលយ័បានជោគជយ័';
$lang['offices_error_adding_updating'] = 'អ្នកមានបញ្ហាក្នុងការកែប្រែ ឬ បន្ថែមថ្មី​នៃការិយាលយ័';
$lang['offices_successful_deleted']='ការលុបរបស់អក្នបានជោគជ័យ';
$lang['offices_one_or_multiple']='ការិយាល័យ(s)';
$lang['offices_cannot_be_deleted']='ការលុបការិយាល័យមានបញ្ហា,​ អ្នកមិនអាចបន្តការលុបនេះបានទេ';
$lang['offices_list_view']=' បង្ហាញទាំងអស់';
$lang['offices_id']='ល.រ';

?>
<?php
$lang['login_login']='ចូល';
$lang['login_username']='ឈ្មោះអ្នកប្រើ';
$lang['login_password']='ពាក្យសម្ងាត់';
$lang['login_go']='Go';
$lang['login_invalid_username_and_password']='ឈ្មោះឫពាក្យសម្ងាត់អ្នកប្រើមិនត្រឹមត្រូវ ';
$lang['login_welcome_message']='សូមស្វាគមន៍មកកាន់ប្រព័ន្ធគ្រប់គ្រងទេសចរណ៍។ ដើម្បីបន្តការប្រើសូមប្រើឈ្មោះអ្នកប្រើនិងពាក្យសម្ងាត់របស់អ្នកដើម្បីចូលប្រើប្រាស់។';
$lang['login_version'] = 'Version';
$lang['login_confirm_password'] = 'បញ្ជាក់ពាក្យសម្ងាត់';
$lang['login_reset_password_for'] = 'កំណត់ពាក្យសម្ងាត់សម្រាប់';
$lang['login_reset_password'] = 'កំណត់ពាក្យសម្ងាត់សារជាថ្មី';
$lang['login_reset_password_message'] = 'អ្នកបានស្នើឱ្យកំណត់ពាក្យសម្ងាត់របស់អ្នកសូមចុចតំណភ្ជាប់ខាងក្រោមដើម្បីបញ្ចប់ដំណើរការកំណត់ពាក្យសម្ងាត់';
$lang['login_password_reset_has_been_sent'] = 'ការកំណត់ឡើងវិញនូវពាក្យសម្ងាត់ ត្រូវបានផ្ញើទៅអ៊ីមែលរបស់អ្នក។ សូមពិនិត្យមើលអ៊ីមែលរបស់អ្នកហើយចុចលើតំណភ្ជាប់។';
$lang['login_password_has_been_reset'] = 'ពាក្យសម្ងាត់របស់អ្នកត្រូវបានកំណត់ឡើងវិញសូមចុចតំណភ្ជាប់ខាងក្រោម: ';
$lang['login_passwords_must_match_and_be_at_least_8_characters'] = 'ពាក្យសម្ងាត់ត្រូវតែផ្គូផ្គងនិងមានយ៉ាងហោចណាស់ 8 តួ';
$lang['login_subscription_cancelled_within_30_days'] = 'ការយល់ព្រមរបស់អ្នកត្រូវបានគេលុបចោលទើប។សូមទាក់ទង support@cabdico.com ដើម្បីធានាបាននូវសេវា';
$lang['login_subscription_terminated'] = 'ការយល់ព្រមរបស់អ្នកត្រូវបានបញ្ចប់។សូមទាក់ទង support@cabdico.com ដើម្បីពិភាក្សា';
$lang['login_application_mismatch'] = 'មានភាពខុសគ្នានៃកំណែកម្មវិធីនិងមូលដ្ឋានទិន្នន័យមួយគឺសូមធ្វើការកែប្រែមូលដ្ឋានទិន្នន័យរបស់អ្នកមុនពេលចូលប្រែប្រាស់';
?>
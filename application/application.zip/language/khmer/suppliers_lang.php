<?php
$lang['suppliers_new']=' អក្នផ្កត់ផ្កងថ្មី';
$lang['suppliers_supplier']='អក្នផ្កត់ផ្កង';
$lang['suppliers_update']='កែប្រែ អក្នផ្កត់ផ្កង';
$lang['suppliers_confirm_delete']='តើអក្នពិតជាចង់លុបអក្នផ្កត់ផ្កងមួយនេះ?';
$lang['suppliers_none_selected']='សូមជ្រើសរើសមុនពេលលុប!';
$lang['suppliers_error_adding_updating'] = 'មានកំហុសក្នុងការបន្ថែម ឫ លុបអក្នផ្កត់ផ្កង';
$lang['suppliers_successful_adding']='ការបន្ថែមអក្នផ្កត់ផ្កងថ្មីបានជោគជ័យ';
$lang['suppliers_successful_updating']='ការកែប្រែអក្នផ្កត់ផ្កងថ្មីបានជោគជ័យ';
$lang['suppliers_successful_deleted']='ការលុបរបស់អក្នបានជោគជ័យ';
$lang['suppliers_one_or_multiple']='អក្នផ្កត់ផ្កង(';
$lang['suppliers_cannot_be_deleted']='អក្នមិនអាចលុបអក្នផ្កត់ផ្កងនេះបានទេពីព្រោះអក្នផ្កត់ផ្កងនេះត្រូវបានគេជ្រើសរើសដើម្បីដាក់លក់ហើយ';
$lang['suppliers_basic_information']='ពត៍មានអក្នផ្កត់ផ្កង';
$lang['suppliers_account_number']='លេខគណនី #';
$lang['suppliers_company_name']='ឈ្មោះក្រុមហ៊ុន';
$lang['suppliers_company_name_required'] = 'សូមបំពេញឈ្មោះក្រុមហ៊ុន';
$lang['suppliers_supplier_type'] = 'ប្រភេទនៃអក្នផ្កត់ផ្គង';
?>
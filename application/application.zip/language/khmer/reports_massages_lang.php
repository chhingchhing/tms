<?php
$lang['reports_report_massages'] = 'របាយការណ៍​ម៉ាស្ស៉ា';
$lang['reports_massages'] = 'ម៉ាស្ស៉ា';
$lang['summary_reports_issue_date'] = 'កាលបរិច្ឆេទ';
$lang['summary_reports_kind_mas'] = 'ប្រភេទ​ម៉ាស្ស៉ា​';
$lang['summary_reports_price'] = 'តម្លៃ';
$lang['summary_reports_time_out'] = 'ម៉ោងចូល';
$lang['summary_reports_time_in'] = 'ម៉ោងចេញ';
$lang['summary_reports_total_time'] = 'សរុបពេល';
$lang['summary_reports_total'] = 'សរុប';
$lang['summary_reports_staff'] = 'ឈ្មោះបុគ្គលិក';
$lang['summary_reports_massage_id'] = 'ម៉ាស្ស៉ា ID';
$lang['summary_reports_massage_time_in'] = 'ម៉ោងចូល';
$lang['summary_reports_massage_time_out'] = 'ម៉ោងចេញ';
$lang['summary_reports_massage_name'] = 'ឈ្មោះម៉ាស្ស៉ា';
$lang['summary_reports_massage_cost'] = 'តម្លៃដើម';
$lang['summary_reports_massage_sale_price'] = 'តម្លៃលក់';
$lang['summary_reports_massage_qty'] = 'ចំនួន (ម៉ោង)';
$lang['summary_reports_massage_comment'] = 'យោបល់';
$lang['summary_reports_massage_disc'] = 'បញ្ចុះតម្លៃ ($)';
$lang['summary_reports_massage_commission_price'] = 'តម្លៃអ្នកនាំភ្ញៀវមក';
$lang['summary_reports_massage_total_commissioner_price']= 'សរុបតម្លៃអ្នកនាំភ្ញៀវមក';
$lang['reports_reports_massage_summary_report'] = 'របាយការណ៍បូកសរុបទំនិញ​ ម៉ាស្ស៉ា';
$lang['summary_reports_massage_massager'] = 'អ្នកម៉ាស្សា';
$lang['summary_reports_massage_office'] = 'ការិយាលយ័';

?>
<?php
$lang['error_no_permission_module']='អក្នមិនមានសិទិ្ជចូលប្រើប្រាស់ផ្នែកនេះទេ';
$lang['error_unknown']='មិនស្គាល់';
?>
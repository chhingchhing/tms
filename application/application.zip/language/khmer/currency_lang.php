<?php
$lang['currency_currency']='​ រូបិយវត្ថុ';
$lang['currency_new']=' រូបិយវត្ថុថ្មី';
$lang['currency_id']='​ល.រ';
$lang['currency_no_currency_display'] = 'ពុំមានរូបិយវត្ថុណាមួយសំរាប់បង្ហាញទេ';
$lang['currency_update']='កែប្រែ រូបិយវត្ថុ';
$lang['currency_currency_value']='តម្លៃ រូបិយវត្ថុ';
$lang['currency_type_name']='ប្រភេទ នៃ រូបិយវត្ថុ';
$lang['currency_value']='អត្រា នៃ រូបិយវត្ថុ';
$lang['currency_basic_information']='ពត៏មាន​ នៃ រូបិយវត្ថុ';
$lang['currency_successful_adding']='ការបន្ថែមរូបិយវត្ថុថ្មីបានជោគជយ័';
$lang['currency_successful_updating']='ការកែប្រែរូបិយវត្ថុបានជោគជយ័';
$lang['currency_error_adding_updating'] = 'មានកំហុសក្នុងការកែប្រែ ឬ បន្ថែមរូបិយវត្ថុថ្មី';
$lang['currency_successful_deleted']='ការលុបរបស់អក្នបានជោគជ័យ';
$lang['currency_one_or_multiple']='រូបិយវត្ថុ(s)';
$lang['currency_cannot_be_deleted']='អ្នកមិនអាចលុបរូបិយវត្ថុនេះបានទេ.';
$lang['currency_currency_symbol']='សញ្ញា នៃ រូបិយវត្ថុ';
?>